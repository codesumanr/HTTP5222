const express = require('express');
const fs = require('fs');
const path = require('path');
const { DOMParser } = require("xmldom");

const app = express();
const PORT = 8088;

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));

let libraryData = [];

function loadLibraryData() {
    const data = fs.readFileSync(path.join(__dirname, "public", "library-branch-locations.kml"), "utf8");
    const xml = new DOMParser().parseFromString(data, "text/xml");
    const placemarks = xml.getElementsByTagName("Placemark");

    libraryData = Array.from(placemarks).map((placemark, index) => ({
        id: index,
        name: placemark.getElementsByTagName("name")[0]?.textContent || "No name",
        description: placemark.getElementsByTagName("description")[0]?.textContent || "No description",
        address: placemark.getElementsByTagName("address")[0]?.textContent || "No address",
        phone: placemark.getElementsByTagName("phoneNumber")[0]?.textContent || "No phone",
    }));
}

loadLibraryData();

app.get("/", (req, res) => {
    res.render("index", { branches: libraryData });
});

app.get("/library/:id", (req, res) => {
    const branch = libraryData[req.params.id];

    if (!branch) {
        return res.status(404).send("Library branch not found");
    }

    res.render("library", { branch });
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
