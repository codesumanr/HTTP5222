import React from 'react';
import './header.css';

const Header = () => {
  return (
    <>
      <header className="header-container">
        <div className="header-content">
          <h1 className="logo">Trivia</h1>
          <nav className="nav-links">
            <a href="/" className="nav-link">Home</a>
            <a href="/about" className="nav-link">About</a>
          </nav>
        </div>
      </header>
      
      <div className="welcome-section">
        <h2 className="welcome-title">Welcome to Trivia</h2>
        <p className="welcome-subtitle">Here's your random question</p>
        <h3 className="question-type">True or false:</h3>
      </div>
    </>
  );
};

// This should be in a separate Question.jsx file
const Question = () => (
  <div className="question-container">
    <div className="question-category">Science & Nature</div>
    <div className="option-true-false">True or false:</div>
    <div className="question-text">
      Pneumonoultramicroscopicsilicovolcanoconiosis is a synonym for silicosis.
    </div>
    <button className="option-button">True</button>
    <button className="reveal-answer">Reveal answer</button>
  </div>
);

export default Header;