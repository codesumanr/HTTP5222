import React, { useState, useEffect } from 'react';
import './question.css';

function decodeHtml(html) {
  const txt = document.createElement("textarea");
  txt.innerHTML = html;
  return txt.value;
}

function Question() {
  const [category, setCategory] = useState(null);
  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const apiUrl = 'https://opentdb.com/api.php?amount=1&category=19&difficulty=medium&type=boolean&encode=url3986';

    setLoading(true);
    setError(null);

    fetch(apiUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.response_code !== 0) {
          throw new Error('API returned an error code: ' + data.response_code);
        }

        if (data.results && data.results.length > 0) {
          const questionData = data.results[0];
          setCategory(decodeHtml(questionData.category));
          setQuestion(decodeHtml(questionData.question));
          setAnswer(decodeHtml(questionData.correct_answer));
          setRevealed(false);
        } else {
          throw new Error('No question data found in the API response.');
        }
        setLoading(false);
      })
      .catch(fetchError => {
        console.error("Error fetching trivia question:", fetchError);
        setError(fetchError.message || "An unknown error occurred during fetch.");
        setLoading(false);
      });
  }, []);

  const handleRevealClick = () => {
    setRevealed(true);
  };

  if (loading) {
    return <div>Loading question...</div>;
  }

  if (error) {
    return <div>Error loading question: {error}. Please try refreshing the page later.</div>;
  }

  return (
    <div className="question-container">
      <div className="question-category">{category}</div>
      <h3 className="question-text">{question}</h3>
      
      <div className="answer-section">
        {revealed && (
          <div className="correct-answer">
            <span className="answer-text">{answer}</span>
          </div>
        )}
        
        <button 
          className={`reveal-button ${revealed ? 'revealed' : ''}`}
          onClick={handleRevealClick}
        >
          {revealed ? 'Answer Revealed' : 'Reveal Answer'}
        </button>
      </div>
    </div>
  );
}

export default Question;