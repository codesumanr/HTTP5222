//import { useState } from 'react'
import Header from './components/Header';    // Import the Header component
import Question from './components/Question';  // Import the Question component


import './App.css'


function App() {
  

  return (
    <>
     
     
      <div className="App"> {/* Keep or remove className="App" as you prefer */}
      <Header /> {/* Render the Header component */}

      <main>
        {/* Add the Question component to the page */}
        <Question />
      </main>

      {/* You could add a Footer here if desired */}
      {/* <footer>Footer Content</footer> */}
    </div>
      <p className="read-the-docs">
       Http 5222, 2025
      </p>
    </>
  )
}

export default App
