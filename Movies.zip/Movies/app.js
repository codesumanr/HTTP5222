require("dotenv").config(); // Load environment variables

const express = require("express");
const axios = require("axios");

const app = express();
const PORT = process.env.PORT || 3000;

// Set Pug as the template engine
app.set("view engine", "pug");

// Trakt API credentials from .env
const TRAKT_API_URL = "https://api.trakt.tv";
const TRAKT_CLIENT = process.env.TRAKT_CLIENT_ID;

const traktHeaders = {
    "Content-Type": "application/json",
    "trakt-api-version": "2",
    "trakt-api-key": TRAKT_CLIENT,
};

app.get("/", async (req, res) => {
    try {
        const response = await axios.get(`${TRAKT_API_URL}/shows/anticipated?limit=15`, { headers: traktHeaders });

        const shows = response.data.map((item) => ({
            title: item.show.title,
            year: item.show.year,
            imdb_id: item.show.ids.imdb,
        }));

        res.render("index", { shows });
    } catch (error) {
        console.error("Error fetching data from Trakt:", error.message);
        res.status(500).send("Error fetching data.");
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`); // Use backticks here
});