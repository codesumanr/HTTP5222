const mongoose = require("mongoose");
require("dotenv").config(); // Load environment variables

// Correct MongoDB connection URL format
const dbUrl = `mongodb+srv://${process.env.DBUSER}:${encodeURIComponent(process.env.DBPWD)}@${process.env.DBHOST}`;

const MovieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  year: { type: Number, required: true },
  rating: { type: String, required: true }
});

const Movie = mongoose.model("Movie", MovieSchema);

// Connect to MongoDB
(async () => {
  try {
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(dbUrl);
      console.log("✅ Connected to MongoDB");
    }
  } catch (error) {
    console.error("❌ MongoDB connection error:", error);
  }
})();

// Get all movies (Sorted by latest first)
async function getMovies() {
  return await Movie.find({}).sort({ year: -1 });
}

// Initialize database with default movie list
async function initializeMovies() {
  const movieList = [
    { title: "Interstellar", year: 2014, rating: "PG-13" },
    { title: "The Godfather", year: 1972, rating: "R" },
    { title: "Parasite", year: 2019, rating: "R" },
    { title: "Inception", year: 2010, rating: "PG-13" },
    { title: "The Matrix", year: 1999, rating: "R" },
    { title: "Gladiator", year: 2000, rating: "R" },
    { title: "Forrest Gump", year: 1994, rating: "PG-13" }
  ];
  
  await Movie.deleteMany({});
  await Movie.insertMany(movieList);
  console.log("🎬 Database initialized with new movie list");
}

// Add a new movie
async function addMovie(title, year, rating) {
  await new Movie({ title, year, rating }).save();
  console.log(`✅ Added movie: ${title} (${year}, ${rating})`);
}

// Update movie rating
async function updateMovieRating(title, newRating) {
  await Movie.updateOne({ title }, { rating: newRating });
  console.log(`🔄 Updated rating for ${title} to ${newRating}`);
}

// Delete movies by rating
async function deleteMoviesByRating(rating) {
  await Movie.deleteMany({ rating });
  console.log(`🗑 Deleted all movies with rating: ${rating}`);
}

// Export functions
module.exports = {
  getMovies,
  initializeMovies,
  addMovie,
  updateMovieRating,
  deleteMoviesByRating
};
