const express = require("express");
const path = require("path");
const dotenv = require("dotenv");

// Load environment variables from .env
dotenv.config();

const db = require("./modules/movies/db");


// Set up Express app
const app = express();
const port = process.env.PORT || 8888;

// Set up template engine
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Initialize database if empty
(async () => {
  try {
    const movies = await db.getMovies();
    if (!movies.length) {
      await db.initializeMovies();
    }
  } catch (error) {
    console.error("Error initializing database:", error);
  }
})();

// Routes
app.get("/", async (req, res) => {
  try {
    const movieList = await db.getMovies();
    res.render("index", { movies: movieList });
  } catch (error) {
    console.error("Error fetching movies:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/add", async (req, res) => {
  try {
    await db.addMovie("Inception", 2010, "PG-13"); // Changed movie title
    res.redirect("/");
  } catch (error) {
    console.error("Error adding movie:", error);
    res.status(500).send("Failed to add movie");
  }
});

app.get("/update", async (req, res) => {
  try {
    await db.updateMovieRating("The Dark Knight", "PG-13"); // Changed movie title
    res.redirect("/");
  } catch (error) {
    console.error("Error updating movie rating:", error);
    res.status(500).send("Failed to update movie rating");
  }
});

app.get("/delete", async (req, res) => {
  try {
    await db.deleteMoviesByRating("R"); // Delete all R-rated movies
    res.redirect("/");
  } catch (error) {
    console.error("Error deleting movies:", error);
    res.status(500).send("Failed to delete movies");
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
