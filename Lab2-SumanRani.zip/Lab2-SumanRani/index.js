const express = require("express");
const path = require("path");

const app = express();

// Set Pug as the view engine
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "templates"));

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.get("/", (req, res) => {
  res.render("index", {
    title: "ShopEasy | Your One-Stop E-commerce Shop",
    categories: ["Electronics", "Fashion", "Home Appliances", "Sports", "Books"],
    featuredProducts: [
      { name: "Wireless Headphones", price: "$59.99", img: "/images/1234567.jpg" },
      { name: "Smartwatch", price: "$149.99", img: "/images/sw344.jpg" },
      { name: "Air Fryer", price: "$89.99", img: "/images/airf123.jpg" },
    ],
  });
});

// Start server
const PORT = 8888;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
