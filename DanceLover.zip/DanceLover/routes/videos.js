const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const channelId = 'UCjOL-pOR48lt4YFtyckEWVQ';
const VIDEOS_PER_PAGE = 10;

// --- CORRECTED fetchVideos Function ---
const fetchVideos = async (pageToken = '') => {
    console.log("Entering fetchVideos function..."); // Log entry

    const apiKey = process.env.YOUTUBE_API_KEY;
    console.log("Using YouTube API Key:", apiKey ? 'Key Present' : '!!! KEY MISSING or UNDEFINED !!!');

    // Check if API key is missing 
    if (!apiKey) {
        console.error("YouTube API Key is missing in environment variables.");
        console.log("fetchVideos: Returning null due to missing API Key.");
        return null; 
    }

    const apiUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&order=date&type=video&maxResults=${VIDEOS_PER_PAGE}&key=${apiKey}&pageToken=${pageToken}`;
    console.log("Attempting to fetch from URL:", apiUrl);

    try {
        const response = await fetch(apiUrl);
        console.log(`YouTube API Response Status: ${response.status} ${response.statusText}`);

        if (!response.ok) {
            // Handle HTTP errors 
            const errorData = await response.text();
            console.error(`HTTP error! Status: ${response.status}. Error details: ${errorData}`);
            console.log("fetchVideos: Returning null due to !response.ok"); 
            return null; 
        }

        console.log("fetchVideos: Attempting to parse JSON response...");
        const data = await response.json(); 
        console.log("fetchVideos: Returning parsed data object."); 
        return data; 
    } catch (error) {
        
        console.error('Error during fetch operation or JSON parsing in fetchVideos:', error);
        console.log("fetchVideos: Returning null due to error in try block."); // Log before return
        return null; 
    }
   
};

// --- Route Handler
router.get('/', async (req, res) => {
    const pageToken = req.query.pageToken || '';
    console.log(`Loading /videos route with pageToken: '${pageToken}'`);
    try {
        const data = await fetchVideos(pageToken); 
        console.log("Raw value returned by fetchVideos:", data === null ? 'null' : (typeof data)); 

        let videos = [];
        let prevPageToken = null;
        let nextPageToken = null;
        let totalVideos = 0;
        let errorMsg = null;

        if (data === null) {
            console.log("fetchVideos returned null, indicating an API or fetch error occurred.");
            errorMsg = 'Could not retrieve videos from YouTube at this time.';
        }
        // Check if data is valid 
        else if (data && data.items) {
            // API call was successful, process items
            videos = data.items;
            prevPageToken = data.prevPageToken || null;
            nextPageToken = data.nextPageToken || null;
            totalVideos = data.pageInfo ? data.pageInfo.totalResults : 0;
            console.log(`Successfully processed API response. Number of videos found: ${videos.length}`);
            if (videos.length === 0) {
                console.log("API returned 0 video items for this request (might be no new videos).");
            }
        } else {
            // Handle unexpected *valid* data structure from API 
            console.log("API response received, but 'items' array is missing or data structure is invalid:", data);
            errorMsg = 'Received an unexpected response structure from YouTube.';
           
            console.error("Unexpected data structure:", JSON.stringify(data, null, 2));
        }

        console.log(`Rendering videos.pug with ${videos.length} videos.`);
        res.render('videos', {
            // title: 'Trending Dance Videos', 
            videos: videos,
            prevPageToken: prevPageToken,
            nextPageToken: nextPageToken,
            totalVideos: totalVideos,
            error: errorMsg
        });

    } catch (error) {
        // This catch block handles unexpected errors 
        console.error('Unexpected error in /videos route handler:', error);
        res.status(500).render('videos', { 
            videos: [],
            prevPageToken: null,
            nextPageToken: null,
            totalVideos: 0,
            error: 'An unexpected server error occurred while loading videos.'
        });
    }
});

module.exports = router;