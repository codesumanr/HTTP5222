import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <h1>Tech Blog</h1>
      <p>Your go-to place for the latest in technology</p>
    </header>
  );
};

export default Header;