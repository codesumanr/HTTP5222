import React from 'react';
import './Hero.css';


const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h2>Welcome to the Tech Blog</h2>
        <p>Discover the latest trends in technology, programming, and innovation.</p>
        <button>Explore More</button>
        
        {/* Add the images with related information */}
        <div className="hero-images">
          <div className="image-card">
            <img src="/src/images/tech.png" alt="Tech" />
            <p>Learn about the latest advancements in technology and how they shape the future.</p>
          </div>
          <div className="image-card">
            <img src="/src/images/react.png" alt="React" />
            <p>Master React.js and build modern, interactive web applications with ease.</p>
          </div>
          <div className="image-card">
            <img src="/src/images/java.png" alt="Java" />
            <p>Explore Java programming, from basics to advanced concepts, for robust software development.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;