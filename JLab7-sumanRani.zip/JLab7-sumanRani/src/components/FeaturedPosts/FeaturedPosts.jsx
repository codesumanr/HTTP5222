import React from 'react';
import './FeaturedPosts.css';

const FeaturedPosts = () => {
  // List of featured blog posts with updated titles
  const posts = [
    {
      id: 1,
      title: 'Getting Started with React for Beginners',
      excerpt: 'Learn the basics of React and build your first web application with this step-by-step guide.',
    },
    {
      id: 2,
      title: 'How AI is Changing the World in 2025',
      excerpt: 'Discover the latest advancements in AI and how they are impacting industries like healthcare, finance, and more.',
    },
    {
      id: 3,
      title: '5 Must-Learn Programming Languages in 2025',
      excerpt: 'Find out which programming languages are essential for developers this year and why they matter.',
    },
  ];

  return (
    <section className="featured-posts">
      {/* Heading for the featured posts section */}
      <h2>Featured Posts</h2>

      {/* Grid layout for displaying posts */}
      <div className="posts-grid">
        {/* Loop through the posts array and render each post */}
        {posts.map((post) => (
          <div key={post.id} className="post-card">
            {/* Post title */}
            <h3>{post.title}</h3>

            {/* Short description of the post */}
            <p>{post.excerpt}</p>

            {/* Link to read the full post */}
            <a href={`/post/${post.id}`} className="read-more">
              Read More
            </a>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FeaturedPosts;