import React from 'react';
import Header from './components/Header/Header';
import Menu from './components/Menu/Menu';
import Hero from './components/Hero/Hero';
import FeaturedPosts from './components/FeaturedPosts/FeaturedPosts';
import Footer from './components/Footer/Footer';
import './index.css';

function App() {
  return (
    <div className="App">
      <Header />
      <Menu />
      <Hero />
      <FeaturedPosts />
      <Footer />
    </div>
  );
}

export default App;