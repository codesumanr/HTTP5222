// Import required modules
const express = require("express");
const { request } = require("http");
const path = require("path"); //contains method to help with path conactenation
const { MongoClient, ObjectId } = require("mongodb"); //require mongodb

//connect to DB
const dbUrl = "mongodb://127.0.0.1:27017/testdb"; // connection string to connect to localhost db and select the tesdb
const client = new MongoClient(dbUrl);

//Set up Express App
const app = express();
//express() is a function to initialize an express app

const port = process.env.PORT || "8888";

//set up template engine
app.set("views",path.join(__dirname,"templates")); 
//set "views" to use the <app_directory> /templates folder to store template files

app.set("view engine", "pug");
//set Express to use Pug as the template (view) engine

//set up folder for static files like CSS, Client-side js
app.use(express.static(path.join(__dirname,"public")));

app.use(express.urlencoded({ extended: true})); //extend the urlencoded format (i.e. query string format like weight=0&path=/&name=Home)

app.use(express.json()); //allow for form data retrieval as JSON {weight:0, path: "/", name: "Home"}

//TEST APP PATH
app.get("/", async(request,response) => {
    let links = await getLinks();
// response.status(200).send("Test");
response.render("index",{title: "Home", menu: links});
});
//this "index" is index.pug beacuse it assumes it's pug extension as view engine is pug
//ADMIN PAGES
app.get("/admin/menu", async (request, response) => {
    let links = await getLinks();
    //render admin page
    response.render("menu-list", {title: "Home", menu: links})
});



//now, I want to render the About page
app.get("/about", async(request,response) => {
    let links = await getLinks()
    response.render("about",{title: "About", menu: links});
});
app.get("/admin/menu/add", async (request, response) => {
    let links = await getLinks();
    //render admin page
    response.render("menu-add", {title: "Add menu link", menu: links})
});

app.post("/admin/menu/add/submit", async (request, response) => {
    //for POST forms (for this submission), data is sent in request.body
    //for GET forms, data is sent in request.query
    //console.log(request.body.path)
    let newLink = {
        weight: request.body.weight,
        path: request.body.path,
        name: request.body.name
    };
    await addLink(newLink);
    response.redirect("/admin/menu"); //redirect back to main menu admin page

});

//Set up server listening
app.listen(port,() => {
console.log(`Listening at http://localhost:${port}`);
});

//MONGOdb helper functions

//Function to connect and return  the testdb database
async function connection() {
    db = client.db();
    return db;

    
}
//function to Get all menu links
async function getLinks() {
    db = await connection();
    let results = db.collection("menuLinks").find({}); //use empty{} as the query to select (find) all
    let resultArray = await results.toArray(); //convert the results pointer to an array we can use (toArray() is an asynchronous method so we need to use await)
    return resultArray;
}
//expects a link JSON object to be inserted into menuLinks
async function addLink(link){
    db = await connection();
    let status = await db.collection("menuLinks").insertOne(link);
    console.log("link added");

}

app.get("/admin/menu/delete", async (request, response) => {
    console.log(request.query.linkId);
    let id = request.query.linkId;
    await deleteLink(id);
    response.redirect("/admin/menu");
}
)
async function deleteLink(id) {
    db = await connection();
    let query = {_id: new ObjectId(id)};
    let result = await db.collection("menuLinks").deleteOne(query);
    
}

//update functionality
async function getSingleLink(id) { 
    db = await connection();
    const editId = { _id: new ObjectId(id) }; 
    const result = await db.collection("menuLinks").findOne(editId); 
    return result; 
    
}

app.get("/admin/menu/edit", async (request, response) => { 
    if (request.query.linkId) { 
    let linkToEdit = await getSingleLink(request.query.linkId); 
    let links = await getLinks(); 
    
    response.render("menu-edit", { title: "Edit menu link", menu: links, editLink: linkToEdit }); 
    } else { 
    response.redirect("/admin/menu"); 
    }   

}); 

app.post("/admin/menu/edit/submit", async (request, response) => { 
    
    let idFilter = { _id: new ObjectId(request.body.linkId) }; 
    
    let link = { 
        weight: request.body.weight,
        path: request.body.path, 
        name: request.body.name 
    }; 
    await editLink(idFilter, link); 
    
    response.redirect("/admin/menu"); 
    }); 
    
async function editLink(filter, link) { 
db = await connection();
const updateSet = {
    $set: link
    };

const updateResult = await db.collection("menuLinks").updateOne(filter, updateSet); 
return updateResult; 

}
