import collection from'./collection.js';

// Add items to the collection
collection.addItem("apples");
collection.addItem("oranges");
collection.addItem("cherries");

// Get and log the number of items in the collection
console.log("Total items in the collection: " + collection.getItemCount()); // Output: 3
