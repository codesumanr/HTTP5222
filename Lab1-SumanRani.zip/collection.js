class Collection {
  constructor() {
    // Private array to store items
    this.items = [];
  }

  // Method to add a new item to the array
  addItem(item) {
    this.items.push(item);
  }

  // Method to get the number of items in the array
  getItemCount() {
    return this.items.length;
  }
}

// Export a singleton instance of the Collection class
const collectionInstance = new Collection();
export default collectionInstance;
