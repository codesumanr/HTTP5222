// Example of Blocking Code
console.log("Start of the program - Blocking Code");

function blockingfuction() {
  // Simulate a blocking operation that lasts for 3 seconds
  const start = Date.now();
  while (Date.now() - start < 3000) {
    // Keep the CPU busy
  }
}

blockingfuction(); // Blocks further execution until it finishes

console.log("End of the program - Blocking Code");

/* Explanation:
The `heavyComputation` function is synchronous and occupies the CPU for 3 seconds,
causing the program to pause before moving to the next line.
*/

// Example of Non-Blocking Code
console.log("\nStart of the program - Non-Blocking Code");

setTimeout(() => {
  // Asynchronous task completes after 2 seconds
  console.log("Async operation finished (2 seconds delay).");
}, 2000);

console.log("End of the program - Non-Blocking Code");

/* Explanation:
The `setTimeout` function schedules the task to execute after a 2-second delay.
Meanwhile, the program continues to execute the next lines of code without waiting.
*/

